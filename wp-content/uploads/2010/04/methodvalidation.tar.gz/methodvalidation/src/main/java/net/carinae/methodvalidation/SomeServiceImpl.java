package net.carinae.methodvalidation;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.apache.bval.constraints.NotEmpty;


public class SomeServiceImpl {
	
	@ValidatedConstructorCall
	public SomeServiceImpl(@NotNull String name) {
		System.out.println("Inside constructor");
	}
	
	@ValidatedMethodCall
	public void simpleMethod(@NotNull @Size(min=10) String arg1) {
		System.out.println("In simple method body.");
	}
	
	@ValidatedMethodCall
	@Pattern(regexp="[a-f0-9]{4}")
	public String simpleReturnMethod(@NotNull @NotEmpty String arg1) {
		return arg1 + "ab";
	}

}
