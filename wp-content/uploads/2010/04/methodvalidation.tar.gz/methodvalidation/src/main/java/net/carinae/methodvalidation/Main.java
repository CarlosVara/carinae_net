package net.carinae.methodvalidation;

import javax.validation.ValidationException;

public class Main {
	
	public static void main(String... args) {
		
		SomeServiceImpl userService;
		
		// Invalid call to the constructor
		try {
			userService =  new SomeServiceImpl(null);
			System.out.println("FAIL - Constructor not correctly validated.");
		} catch (ValidationException e) {
			System.out.println("1 - Constructor correctly validated.");
		}
		
		// Valid call
		userService =  new SomeServiceImpl("hello");
		
		// Invalid params in method call
		try {
			userService.simpleMethod("short");
			System.out.println("FAIL - Method call not correctly validated.");
		} catch (ValidationException e) {
			System.out.println("2 - Method call correctly validated.");
		}
		
		// Invalid return value
		try {
			userService.simpleReturnMethod("z");
			System.out.println("FAIL - Return value not correctly validated.");
		} catch (ValidationException e) {
			System.out.println("3 - Return value correctly validated.");
		}
		
	}
	
}
